﻿f1::ExitApp
 
#IfWinActive YandereSimulator
 
{
 q::a
 w::z
 a::q
 z::w
}