/////////////////////////////
///// SAVE DATA WARNING /////
/////////////////////////////

Your save data is stored in these two folders:
 
YandereSimulator\Assets\StreamingAssets\SaveData
YandereSimulator\Assets\StreamingAssets\SaveFiles
 
When you update to a new build of the game, you will lose your progress unless you transfer your save data from the old build into the new build.

////////////////////////////////////
///// CUSTOM MODE DATA WARNING /////
////////////////////////////////////
 
Whenever you update to a new build, the game won't be aware of anything you created in Custom Mode in any previous build of the game. If there is anything you've created using Custom Mode that you want to retain access to, you need to back up the following files from your current build of the game:
 
YandereSimulator\Assets\StreamingAssets\CustomMode (the entire directory)
YandereSimulator\Assets\StreamingAssets\PortraitsCustom (the entire directory)
YandereSimulator\Assets\StreamingAssets\JSON\Custom.json
YandereSimulator\Assets\StreamingAssets\JSON\CustomTopics.json
YandereSimulator\Assets\StreamingAssets\JSON\Misc.json
 
...and then drag-and-drop those files into the new build once you download it.
 
This will always be true of every build!
 
Always remember this, so that you never lose any Custom Mode data or save data that is important to you!

///////////////////////////////
///// FORCING DIRECT3D 12 /////
///////////////////////////////

Yandere Simulator uses Direct3D 11. However, if you have a very recent graphics card, the game might run better on Direct3D 12.

If you would like to try launching the game with Direct3D 12, run ForceD3D12.bat